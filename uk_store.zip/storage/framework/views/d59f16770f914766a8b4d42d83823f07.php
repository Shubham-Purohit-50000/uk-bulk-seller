
<?php $__env->startSection('title','My Account'); ?>
<?php $__env->startSection('content'); ?>
<!-- page-title -->
<div class="page-title" style="background-image: url(frontend/images/section/page-title.jpg);">
    <div class="container-full">
        <div class="row">
            <div class="col-12">
                <h3 class="heading text-center">My Account</h3>
                <ul class="breadcrumbs d-flex align-items-center justify-content-center">
                    <li>
                        <a class="link" href="index.html">Homepage</a>
                    </li>
                    <li>
                        <i class="icon-arrRight"></i>
                    </li>
                    <li>
                        <a class="link" href="#">Pages</a>
                    </li>
                    <li>
                        <i class="icon-arrRight"></i>
                    </li>
                    <li>
                        My Account
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- /page-title -->

<div class="btn-sidebar-account">
    <button data-bs-toggle="offcanvas" data-bs-target="#mbAccount"><i class="icon icon-squares-four"></i></button>
</div>

<!-- my-account -->
<section class="flat-spacing">
    <div class="container">
        <div class="my-account-wrap">
            <!-- nav -->
            <?php echo $__env->make('account.side-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- nav end -->
            <!-- my account form  -->
            <div class="my-account-content">
                <div class="account-details">
                    <form action="#" class="form-account-details form-has-password">
                        <div class="account-info">
                            <h5 class="title">Information</h5>
                            <div class="cols mb_20">
                                <fieldset>
                                    <input type="text" tabindex="2" value="<?php echo e(auth()->user()->name, false); ?>" readonly>
                                </fieldset>
                                <fieldset>
                                    <input type="text" tabindex="2" value="<?php echo e(auth()->user()->email, false); ?>" readonly>
                                </fieldset>
                            </div>
                            <div class="cols mb_20">
                                <fieldset>
                                    <input type="text" tabindex="2" value="<?php echo e(auth()->user()->phone, false); ?>" readonly>
                                </fieldset>
                            </div>
                            <div class="cols mb_20">
                                <fieldset>
                                    <textarea readonly><?php echo e(auth()->user()->address, false); ?></textarea>
                                </fieldset>
                            </div>
                        </div>

                        <div class="account-info">
                            <h5 class="title">Level & Type</h5>
                            <div class="cols mb_20">
                                <?php if(auth()->user()->level !== null): ?>
                                <fieldset>
                                    <input type="text" tabindex="2" value="<?php echo e(auth()->user()->level->name, false); ?>" readonly>
                                </fieldset>
                                <?php endif; ?>
                                <fieldset>
                                    <input type="text" tabindex="2" value="<?php echo e(auth()->user()->roles->first()->name ?? 'No Role Assigned', false); ?>" readonly>
                                </fieldset>
                            </div>
                        </div>

                        <?php if(auth()->user()->hasRole('complete-franchise')): ?>
                        <div class="account-info">
                            <h5 class="title">Parent Company</h5>
                            <div class="cols mb_20">
                                <fieldset>
                                    <input type="text" value="<?php echo e(auth()->user()->parentCompany->name, false); ?>" readonly>
                                </fieldset>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasRole('company') or auth()->user()->hasRole('business')): ?>
                        <div class="account-info">
                            <h5 class="title">Relational Manager</h5>
                            <div class="cols mb_20">
                                <fieldset>
                                    <input type="text" value="<?php echo e(auth()->user()->rm->name, false); ?>" readonly>
                                </fieldset>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasRole('relational-manager')): ?>
                        <div class="account-info">
                            <h5 class="title">Commission Rate</h5>
                            <div class="cols mb_20">
                                <fieldset>
                                    <input type="text" value="<?php echo e(auth()->user()->commission, false); ?> %" readonly>
                                </fieldset>
                            </div>
                        </div>
                        <?php endif; ?>

                    </form>
                </div>
        
            </div>
            <!-- end my account form -->
        </div>
    </div>
</section>
<!-- /my-account -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8.2\htdocs\uk_store\resources\views/account/my-account.blade.php ENDPATH**/ ?>