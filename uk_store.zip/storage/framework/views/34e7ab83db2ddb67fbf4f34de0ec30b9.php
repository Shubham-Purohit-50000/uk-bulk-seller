<div class="card">
    <div class="card-header">
        <h3>Scan or Search Product</h3>
    </div>
    <div class="card-body">
        <div class="row">
            <!-- Barcode Scanner Input -->
            <div class="col-md-6">
                <input type="text" id="barcodeInput" class="form-control" placeholder="Scan or enter barcode..." autofocus>
            </div>

            <!-- Product Search Dropdown -->
            <div class="col-md-6">
                <select id="productSearch" class="form-control"></select>
            </div>
        </div>

        <!-- Product List Display -->
        <table class="table mt-4">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="posProductList"></tbody>
        </table>

        <!-- Total Amount -->
        <h4>Total: ₹<span id="totalAmount">0.00</span></h4>
        <button class="btn btn-success" onclick="processOrder()">Checkout</button>
    </div>
</div>
<script>
    var customer_id = <?php echo json_encode($id, 15, 512) ?>; // Pass the PHP variable to JavaScript
</script>

<script>
document.getElementById("barcodeInput").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        fetchProduct(this.value);
        this.value = "";
    }
});

// Fetch Product Details
function fetchProduct(barcode) {
    console.log("Fetching products for ID:", customer_id);
    fetch(`/admin/pos/get-product/${barcode}/${customer_id}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            addProductToCart(data.product);
        } else {
            alert("Product not found!");
        }
    });
}

// Add Product to List
function addProductToCart(product) {
    let tbody = document.getElementById("posProductList");
    let existingRow = document.getElementById(`product-${product.id}`);
    
    if (existingRow) {
        let qtyInput = existingRow.querySelector('.product-qty');
        qtyInput.value = parseInt(qtyInput.value) + 1;
    } else {
        let row = document.createElement("tr");
        row.id = `product-${product.id}`;
        row.innerHTML = `
            <td>${product.name}</td>
            <td>₹${product.price}</td>
            <td><input type="number" class="product-qty" value="1" min="1" onchange="updateTotal()"></td>
            <td class="product-total">₹${product.price}</td>
            <td><button class="btn btn-danger btn-sm" onclick="removeProduct(${product.id})">Remove</button></td>
        `;
        tbody.appendChild(row);
    }
    updateTotal();
}

// Update Total
function updateTotal() {
    let total = 0;
    document.querySelectorAll("#posProductList tr").forEach(row => {
        let price = parseFloat(row.children[1].innerText.replace("₹", ""));
        let qty = parseInt(row.querySelector('.product-qty').value);
        row.querySelector(".product-total").innerText = `₹${(price * qty).toFixed(2)}`;
        total += price * qty;
    });
    document.getElementById("totalAmount").innerText = total.toFixed(2);
}

// Remove Product
function removeProduct(id) {
    document.getElementById(`product-${id}`).remove();
    updateTotal();
}

// Checkout Order
function processOrder() {
    alert("Order processed!");
}
</script>

<!-- jQuery (Must be before Select2) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />

<!-- Select2 JS (After jQuery) -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

<script>
$(document).ready(function() {
    $('#productSearch').select2({
        placeholder: "Search for a product",
        ajax: {
            url: '/admin/pos/search-product',
            dataType: 'json',
            delay: 250,
            processResults: function (data) {
                return {
                    results: data
                };
            }
        }
    });

    $('#productSearch').on('select2:select', function (e) {
        fetchProduct(e.params.data.id);
    });
});
</script>
<?php /**PATH D:\xampp-8.2\htdocs\uk_store\resources\views/admin/epos.blade.php ENDPATH**/ ?>