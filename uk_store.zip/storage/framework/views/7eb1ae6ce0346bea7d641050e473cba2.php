<div class="wrapper-shop row">
    <?php if($products->count() > 0): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-md-3 col-lg-2">
                <?php echo $__env->make('components.product-card', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p class="text-center">No products available in this category.</p>
    <?php endif; ?>
</div><?php /**PATH D:\xampp-8.2\htdocs\uk_store\resources\views/components/shub-product-list.blade.php ENDPATH**/ ?>