
<?php $__env->startSection('title','My Account'); ?>
<?php $__env->startSection('content'); ?>
<!-- page-title -->
<div class="page-title" style="background-image: url(frontend/images/section/page-title.jpg);">
    <div class="container-full">
        <div class="row">
            <div class="col-12">
                <h3 class="heading text-center">My Account</h3>
                <ul class="breadcrumbs d-flex align-items-center justify-content-center">
                    <li>
                        <a class="link" href="index.html">Homepage</a>
                    </li>
                    <li>
                        <i class="icon-arrRight"></i>
                    </li>
                    <li>
                        <a class="link" href="#">Pages</a>
                    </li>
                    <li>
                        <i class="icon-arrRight"></i>
                    </li>
                    <li>
                        My Account
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- /page-title -->

<div class="btn-sidebar-account">
    <button data-bs-toggle="offcanvas" data-bs-target="#mbAccount"><i class="icon icon-squares-four"></i></button>
</div>

<!-- my-account -->
<section class="flat-spacing">
    <div class="container">
        <div class="my-account-wrap">
            <!-- nav -->
            <?php echo $__env->make('account.side-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- nav end -->
            <!-- my order list -->
            <div class="my-account-content">
                <div class="account-orders">
                    <div class="wrap-account-order">
                    <?php if($orders->isEmpty()): ?>
                        <p>No orders found.</p>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th class="fw-6">Order</th>
                                    <th class="fw-6">Date</th>
                                    <th class="fw-6">Status</th>
                                    <?php if(!auth()->user()->hasRole('complete-franchise')): ?>
                                    <th class="fw-6">Total</th>
                                    <?php endif; ?>
                                    <th class="fw-6">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="tf-order-item">
                                    <td>
                                        #<?php echo e($order->id, false); ?>

                                    </td>
                                    <td>
                                        <?php echo e($order->created_at->format('d M Y'), false); ?>

                                    </td>
                                    <td>
                                        <?php if($order->status == 'pending'): ?>
                                            <span class="btn btn-warning">Pending</span>
                                        <?php elseif($order->status == 'in_transit'): ?>
                                            <span class="btn btn-basic">In Transit</span>
                                        <?php elseif($order->status == 'delivered'): ?>
                                            <span class="btn btn-success">Delivered</span>
                                        <?php elseif($order->status == 'canceled'): ?>
                                            <span class="btn btn-danger">Canceled</span>
                                        <?php endif; ?>
                                    </td>
                                    <?php if(!auth()->user()->hasRole('complete-franchise')): ?>
                                    <td>
                                        $<?php echo e(number_format($order->total_amount, 2), false); ?>

                                    </td>
                                    <?php endif; ?>
                                    <td>
                                        <a href="<?php echo e(url('order-items', $order->id), false); ?>" class="tf-btn btn-fill radius-4">
                                            <span class="text">View</span>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
             <!-- my order list end -->
        </div>
    </div>
</section>
<!-- /my-account -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8.2\htdocs\uk_store\resources\views/account/my-orders.blade.php ENDPATH**/ ?>