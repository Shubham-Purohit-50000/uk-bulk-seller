<?php
    use App\Models\CartItem;
    use App\Models\Cart;

    $user = auth()->user();
    $cartItems = [];

    if ($user) {
        $cart = Cart::where('user_id', $user->id)->first();
        if ($cart) {
            $cartItems = CartItem::where('cart_id', $cart->id)
                ->pluck('quantity', 'product_id')
                ->toArray();
        }
    }

    $price = App\Http\Controllers\UserController::getProductPriceForUser($product->id);
    $currentQuantity = isset($cartItems[$product->id]) ? $cartItems[$product->id] : 0;
?>

<div class="card-product grid" data-availability="Out of stock" data-brand="adidas">
    <div class="card-product-wrapper">
        <a href="<?php echo e(url('product-detail/' . $product->slug), false); ?>" class="product-img">
            <?php
                $defaultImage = isset($product->image[0]) ? asset('storage/' . $product->image[0]) : asset('frontend/images/placeholder.jpg');
                $hoverImage = isset($product->image[1]) ? asset('storage/' . $product->image[1]) : $defaultImage;
            ?>

            <img class="lazyload img-product" data-src="<?php echo e($defaultImage, false); ?>" src="<?php echo e($defaultImage, false); ?>" alt="image-product">
            <img class="lazyload img-hover" data-src="<?php echo e($hoverImage, false); ?>" src="<?php echo e($hoverImage, false); ?>" alt="image-product">
        </a>

        <?php if(auth()->guard()->check()): ?>
        <div class="list-btn-main d-block">
            <div class="quantity-selector btn-main-product d-flex">
                <button class="decrement">-</button>
                <input type="number" class="product-qty" id="qty-<?php echo e($product->id, false); ?>" value="<?php echo e($currentQuantity, false); ?>" min="0">
                <button class="increment">+</button>
            </div>
            <div>
                <?php if($currentQuantity <= 0): ?>
                    <a href="#shoppingCart" data-id="<?php echo e($product->id, false); ?>" data-url="<?php echo e(url('update-cart', $product->id), false); ?>" class="btn-main-product add-cart">Add To Cart</a>
                <?php else: ?>
                    <a href="#shoppingCart" data-id="<?php echo e($product->id, false); ?>" data-url="<?php echo e(url('update-cart', $product->id), false); ?>" class="btn-main-product add-cart">Update Cart</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="card-product-info">
        <a href="<?php echo e(url('product-detail/' . $product->slug), false); ?>" class="title link"><?php echo e($product->name, false); ?></a>
        <?php if(auth()->user() && !auth()->user()->hasRole('complete-franchise')): ?>
            <span class="price current-price">$<?php echo e($price, false); ?></span>
        <?php endif; ?>
    </div>
</div>

<?php /**PATH D:\xampp-8.2\htdocs\uk_store\resources\views/components/product-card.blade.php ENDPATH**/ ?>