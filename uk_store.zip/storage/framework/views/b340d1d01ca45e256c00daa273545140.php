
<?php $__env->startSection('title','Checkout'); ?>
<?php $__env->startSection('content'); ?>
<!-- page-title -->
<div class="page-title" style="background-image: url(images/section/page-title.jpg);">
    <div class="container">
        <h3 class="heading text-center">Checkout Page</h3>
        <ul class="breadcrumbs d-flex align-items-center justify-content-center">
            <li><a class="link" href="index.html">Homepage</a></li>
            <li><i class="icon-arrRight"></i></li>
            <li><a class="link" href="shop-default-grid.html">Shop</a></li>
            <li><i class="icon-arrRight"></i></li>
            <li>Shopping Cart</li>
        </ul>
    </div>
</div>
<!-- /page-title -->

<!-- Section cart -->
<section class="flat-spacing">
    <div class="container">
        <div class="row">
            <div class="col-xl-8">
                <?php
                    $store = session('store');
                    $total_price = 0;
                ?>
                <?php if($store): ?>
                <div class="tf-cart-sold">
                    <div class="notification-sold bg-surface">
                        <img class="icon" src="<?php echo e(asset('frontend/images/logo/icon-fire.png'), false); ?>" alt="img">
                        <div class="count-text my-capitalize">
                            <h5>Checkout for : <?php echo e($store->name, false); ?></h5>
                        </div>  
                    </div>
                    <div class="notification-progress">
                        <div class="text">Buy <span class="fw-semibold text-primary">$70.00</span> more to get <span class="fw-semibold">Freeship</span></div>
                        <div class="progress-cart">
                            <div class="value" style="width: 0%;" data-progress="50">
                                <span class="round"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(url('order'), false); ?>" method="post" id="checkout_product_list_form">
                    <?php echo csrf_field(); ?>
                    <table class="tf-table-page-cart">
                        <thead>
                            <tr>
                                <th>Products</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total Price</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(isset($cart)): ?>
                        <?php
                            $cart_items = $cart->cartItems;
                        ?>
                        <?php $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $price =  $item->price;
                                $total_price += $price * $item->quantity;
                            ?>
                            <input type="hidden" name="action" value="cart">
                            <input type="hidden" name="cart_id" value="<?php echo e($cart->id, false); ?>">
                            <tr class="tf-cart-item file-delete">
                                <td class="tf-cart-item_product">
                                    <a href="product-detail.html" class="img-box">
                                        <img src="<?php echo e(asset('storage/' . $item->product->image[0]), false); ?>" alt="product">
                                    </a>
                                </td>
                                
                                <td data-cart-title="Price" class="tf-cart-item_price text-center">
                                    <div class="cart-price text-button price-on-sale">$<?php echo e($price, false); ?></div>
                                    <?php if(auth()->user()->hasRole('relational-manager')): ?>
                                    <div class="d-flex align-items-center gap-2" style="justify-content: center;">
                                        <input type="number" class="form-control" data-item-id="<?php echo e($item->id, false); ?>" name="new_price" style="width: 40%; padding:0 0 0 10px;">
                                        <button class="btn btn-sm btn-success check_price">Apply</button>
                                    </div>
                                    <?php endif; ?>
                                </td>
                                <td data-cart-title="Quantity" class="tf-cart-item_quantity text-center">
                                    <div class="cart-total text-button"><?php echo e($item->quantity, false); ?></div>
                                    <input type="hidden" class="quantity-product" name="quantity" value="<?php echo e($item->quantity, false); ?>">
                                </td>
                                <td data-cart-title="Total" class="tf-cart-item_total text-center">
                                    <div class="cart-total text-button total-price">$<?php echo e($price * $item->quantity, false); ?></div>
                                    <span class="d-none item_total_p"><?php echo e($price * $item->quantity, false); ?></span>
                                </td>
                                <td data-cart-title="Remove" class="remove-cart"><span class="remove icon icon-close"></span></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php elseif(isset($product)): ?>
                            <?php
                                $price =  App\Http\Controllers\UserController::getProductPriceForUser($product->id);
                                $total_price = $price;
                            ?>
                            <input type="hidden" name="action" value="direct">
                            <input type="hidden" name="product_id" value="<?php echo e($product->id, false); ?>">
                            <tr class="tf-cart-item file-delete">
                                <td class="tf-cart-item_product">
                                    <a href="product-detail.html" class="img-box">
                                        <img src="<?php echo e(asset('storage/' . $product->image[0]), false); ?>" alt="product">
                                    </a>
                                </td>
                                <td data-cart-title="Price" class="tf-cart-item_price text-center">
                                    <div class="cart-price text-button price-on-sale">$<?php echo e($price, false); ?></div>
                                </td>
                                <td data-cart-title="Quantity" class="tf-cart-item_quantity">
                                    <div class="wg-quantity mx-md-auto">
                                        <span class="btn-quantity btn-decrease">-</span>
                                        <input type="text" class="quantity-product" name="quantity" value="1">
                                        <span class="btn-quantity btn-increase">+</span>
                                    </div>
                                </td>
                                <td data-cart-title="Total" class="tf-cart-item_total text-center">
                                    <div class="cart-total text-button total-price">$<?php echo e($price, false); ?></div>
                                    <span class="d-none item_total_p"><?php echo e($price, false); ?></span>
                                </td>
                                <td data-cart-title="Remove" class="remove-cart"><span class="remove icon icon-close"></span></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </form>
            </div>
            <div class="col-xl-4">
                <div class="fl-sidebar-cart">
                    <div class="box-order bg-surface">
                        <h5 class="title">Order Summary</h5>
                        <div class="subtotal text-button d-flex justify-content-between align-items-center">
                            <span>Subtotal</span>
                            <span class="total"><?php echo e($total_price, false); ?></span>
                        </div>
                        <div class="discount text-button d-flex justify-content-between align-items-center">
                            <span>Discounts</span>
                            <span class="total">-$80.00</span>
                        </div>
                        <div class="ship">
                            <span class="text-button">Shipping</span>
                            <div class="flex-grow-1">
                                <fieldset class="ship-item">
                                    <input type="radio" name="ship-check" class="tf-check-rounded" id="free" checked>
                                    <label for="free">
                                        <span>Free Shipping</span>
                                        <span class="price">$0.00</span>
                                    </label>
                                </fieldset>
                                <fieldset class="ship-item">
                                    <input type="radio" name="ship-check" class="tf-check-rounded" id="local">
                                    <label for="local">
                                        <span>Local:</span>
                                        <span class="price">$35.00</span>
                                    </label>
                                </fieldset>
                                <fieldset class="ship-item">
                                    <input type="radio" name="ship-check" class="tf-check-rounded" id="rate">
                                    <label for="rate">
                                        <span>Flat Rate:</span>
                                        <span class="price">$35.00</span>
                                    </label>
                                </fieldset>
                            </div>
                        </div>
                        <h5 class="total-order d-flex justify-content-between align-items-center">
                            <span>Total</span>
                            <span class="total gross"><?php echo e($total_price, false); ?></span>
                        </h5>
                        <div class="box-progress-checkout">
                            <fieldset class="check-agree">
                                <input type="checkbox" id="check-agree" class="tf-check-rounded">
                                <label for="check-agree">
                                    I agree with the <a href="term-of-use.html">terms and conditions</a>
                                </label>
                            </fieldset>
                            <button class="tf-btn btn-reset" id="checkout_product_list_form_submit_btn">Process To Checkout</button>
                            <p class="text-button text-center">Or continue shopping</p>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Section cart -->
    <?php $__env->startSection('script'); ?>
    <script>
    $(document).ready(function () {
        $("#checkout_product_list_form_submit_btn").on("click", function (e) {
            e.preventDefault(); // Prevent default button action (if necessary)
            $("#checkout_product_list_form").submit(); // Submit the form manually
        });
    });
    </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8.2\htdocs\uk_store\resources\views/page/checkout.blade.php ENDPATH**/ ?>