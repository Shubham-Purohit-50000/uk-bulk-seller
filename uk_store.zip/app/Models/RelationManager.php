<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RelationManager extends Model
{
    protected $table = 'relation_managers';
}
